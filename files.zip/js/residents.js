const list = document.getElementById('resident-list');
const form = document.getElementById('add-resident-form');
let residents = JSON.parse(localStorage.getItem('residents')) || [];

function renderResidents() {
  list.innerHTML = '';
  residents.forEach((r, idx) => {
    const li = document.createElement('li');
    li.textContent = `${r.name} (Flat: ${r.flat})`;
    const del = document.createElement('button');
    del.textContent = 'Remove';
    del.onclick = () => {
      residents.splice(idx, 1);
      localStorage.setItem('residents', JSON.stringify(residents));
      renderResidents();
    };
    li.appendChild(del);
    list.appendChild(li);
  });
}
form.onsubmit = function(e) {
  e.preventDefault();
  residents.push({ name: document.getElementById('resident-name').value, flat: document.getElementById('resident-flat').value });
  localStorage.setItem('residents', JSON.stringify(residents));
  renderResidents();
  form.reset();
};
renderResidents();