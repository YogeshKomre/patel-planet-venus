// Example: Fetch and display announcements (static for demo)
document.addEventListener('DOMContentLoaded', function() {
  const announcements = [
    { title: "Maintenance Notice", date: "2025-05-20", content: "Water supply will be off from 10AM to 1PM." },
    { title: "Upcoming Society Event", date: "2025-05-25", content: "Join us for the annual festival!" }
  ];
  const list = document.getElementById('announcements-list');
  if (list) {
    announcements.forEach(a => {
      const div = document.createElement('div');
      div.innerHTML = `<strong>${a.title}</strong> (${a.date}): ${a.content}`;
      list.appendChild(div);
    });
  }
});