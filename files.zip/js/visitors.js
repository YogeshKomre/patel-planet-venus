let visitors = JSON.parse(localStorage.getItem('visitors')) || [];
const list = document.getElementById('pending-visitors');
const form = document.getElementById('visitor-form');

function renderVisitors() {
  list.innerHTML = '';
  visitors.forEach((v, idx) => {
    if (!v.approved) {
      const li = document.createElement('li');
      li.textContent = `${v.name} (Purpose: ${v.purpose})`;
      const approve = document.createElement('button');
      approve.textContent = 'Approve';
      approve.onclick = () => {
        visitors[idx].approved = true;
        localStorage.setItem('visitors', JSON.stringify(visitors));
        renderVisitors();
        alert('Visitor approved! (Notify resident)');
      };
      li.appendChild(approve);
      list.appendChild(li);
    }
  });
}

form.onsubmit = function(e) {
  e.preventDefault();
  visitors.push({ name: document.getElementById('visitor-name').value, purpose: document.getElementById('visitor-purpose').value, approved: false });
  localStorage.setItem('visitors', JSON.stringify(visitors));
  renderVisitors();
  form.reset();
};

renderVisitors();