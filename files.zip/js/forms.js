document.querySelectorAll('form').forEach(form => {
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Form submitted! (Implement backend/email integration)');
    form.reset();
  });
});